package studycircle.server.view;

import studycircle.server.controller.ServerController;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

public final class ServerWindow extends JFrame implements ServerController.Listener {
    private static final Color BG = new Color(10, 18, 34);
    private static final Color PANEL = new Color(18, 31, 52);
    private static final Color NAVY = new Color(12, 27, 49);
    private static final Color INPUT = new Color(9, 22, 40);
    private static final Color BLUE = new Color(35, 115, 205);
    private static final Color GREEN = new Color(20, 155, 105);
    private static final Color RED = new Color(210, 75, 75);
    private static final Color TEXT = new Color(230, 238, 248);
    private static final Color MUTED = new Color(151, 170, 194);
    private static final Color BORDER = new Color(43, 68, 96);
    private static final int MAX_LOG_CHARS = 200_000;

    private final JTextField portField;
    private final JButton toggleButton = new JButton("Stop server");
    private final JLabel statusLabel = new JLabel(" Server is stopped.");
    private final JTextArea logArea = new JTextArea();
    private final DefaultListModel<String> usersModel = new DefaultListModel<>();
    private final JLabel usersTitle = new JLabel("Online (0)");
    private final JTextArea addressArea = new JTextArea(4, 20);
    private final ServerController controller;

    public ServerWindow(ServerController controller, int port) {
        super("Study Circle - Server");
        this.controller = controller;
        controller.setListener(this);
        portField = new JTextField(String.valueOf(port), 6);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { controller.shutdown(); dispose(); }
        });

        getContentPane().setBackground(BG);
        setLayout(new BorderLayout(10, 10));
        ((JComponent) getContentPane()).setBorder(new EmptyBorder(12, 12, 10, 12));
        add(buildTopBar(), BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
        statusLabel.setOpaque(true);
        statusLabel.setBackground(NAVY);
        statusLabel.setBorder(new EmptyBorder(9, 10, 9, 10));
        statusLabel.setForeground(RED);
        add(statusLabel, BorderLayout.SOUTH);

        setSize(900, 600);
        setMinimumSize(new Dimension(700, 470));
        setLocationRelativeTo(null);
        refreshAddresses();
        controller.startServer(port);
    }

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        bar.setBackground(NAVY);
        bar.setBorder(new CompoundBorder(new LineBorder(BORDER), new EmptyBorder(3, 5, 3, 5)));

        JLabel title = new JLabel("STUDY CIRCLE SERVER");
        title.setForeground(TEXT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        JLabel port = new JLabel("PORT");
        port.setForeground(MUTED);
        port.setFont(new Font("Segoe UI", Font.BOLD, 10));
        styleField(portField);
        portField.setPreferredSize(new Dimension(85, 34));
        styleButton(toggleButton, RED);

        bar.add(title);
        bar.add(Box.createHorizontalStrut(15));
        bar.add(port);
        bar.add(portField);
        bar.add(toggleButton);
        toggleButton.addActionListener(e -> {
            if (controller.isRunning()) controller.stopServer();
            else controller.startServer(readPort());
        });
        portField.addActionListener(e -> toggleButton.doClick());
        return bar;
    }

    private JSplitPane buildCenter() {
        logArea.setEditable(false);
        logArea.setLineWrap(true);
        logArea.setWrapStyleWord(true);
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logArea.setBackground(INPUT);
        logArea.setForeground(TEXT);
        logArea.setCaretColor(TEXT);
        logArea.setBorder(new EmptyBorder(10, 10, 10, 10));
        ((DefaultCaret) logArea.getCaret()).setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        JButton clear = new JButton("Clear log");
        styleButton(clear, BLUE);
        clear.addActionListener(e -> logArea.setText(""));

        JPanel logPanel = createPanel("SERVER ACTIVITY");
        JPanel logTop = new JPanel(new BorderLayout());
        logTop.setOpaque(false);
        logTop.add(sectionLabel("Live server messages"), BorderLayout.WEST);
        logTop.add(clear, BorderLayout.EAST);
        logPanel.add(logTop, BorderLayout.NORTH);
        logPanel.add(styleScroll(new JScrollPane(logArea)), BorderLayout.CENTER);

        addressArea.setEditable(false);
        addressArea.setFocusable(false);
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        addressArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        addressArea.setBackground(INPUT);
        addressArea.setForeground(TEXT);
        addressArea.setBorder(new EmptyBorder(8, 8, 8, 8));

        JPanel side = new JPanel(new BorderLayout(0, 10));
        side.setOpaque(false);
        side.setBorder(new EmptyBorder(0, 0, 0, 0));

        JPanel addressPanel = createPanel("LAN CONNECTION");
        addressPanel.add(sectionLabel("Clients can connect using:"), BorderLayout.NORTH);
        addressPanel.add(styleScroll(new JScrollPane(addressArea)), BorderLayout.CENTER);
        addressPanel.setPreferredSize(new Dimension(270, 170));
        side.add(addressPanel, BorderLayout.NORTH);

        JPanel users = createPanel("ONLINE MEMBERS");
        usersTitle.setForeground(TEXT);
        usersTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        users.add(usersTitle, BorderLayout.NORTH);
        JList<String> userList = new JList<>(usersModel);
        userList.setBackground(INPUT);
        userList.setForeground(TEXT);
        userList.setSelectionBackground(BLUE);
        userList.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        users.add(styleScroll(new JScrollPane(userList)), BorderLayout.CENTER);
        side.add(users, BorderLayout.CENTER);
        side.setPreferredSize(new Dimension(275, 0));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, logPanel, side);
        split.setResizeWeight(0.70);
        split.setDividerLocation(0.70);
        split.setDividerSize(7);
        split.setBorder(null);
        split.setBackground(BG);
        split.setOpaque(false);
        return split;
    }

    private JPanel createPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBackground(PANEL);
        panel.setBorder(new CompoundBorder(new LineBorder(BORDER), new EmptyBorder(11, 11, 11, 11)));
        JLabel heading = new JLabel(title);
        heading.setForeground(TEXT);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 13));
        panel.add(heading, BorderLayout.WEST);
        return panel;
    }

    private JLabel sectionLabel(String value) {
        JLabel label = new JLabel(value);
        label.setForeground(MUTED);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        return label;
    }

    private void styleField(JTextField field) {
        field.setBackground(INPUT);
        field.setForeground(TEXT);
        field.setCaretColor(TEXT);
        field.setBorder(new CompoundBorder(new LineBorder(BORDER), new EmptyBorder(6, 8, 6, 8)));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    }

    private void styleButton(JButton button, Color color) {
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setBorder(new EmptyBorder(8, 13, 8, 13));
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private JScrollPane styleScroll(JScrollPane scroll) {
        scroll.setBorder(new LineBorder(BORDER));
        scroll.getViewport().setBackground(INPUT);
        scroll.setBackground(PANEL);
        return scroll;
    }

    private void refreshAddresses() {
        List<String> addrs = controller.getLanAddresses();
        addressArea.setText(addrs.isEmpty()
                ? "localhost (no other LAN address found)"
                : String.join("\\n", addrs));
        addressArea.setRows(Math.max(2, addrs.size()));
        addressArea.setCaretPosition(0);
    }

    private int readPort() {
        try {
            int port = Integer.parseInt(portField.getText().trim());
            if (port < 1 || port > 65535) throw new NumberFormatException();
            return port;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "The port must be a number from 1 to 65535.",
                    "Study Circle", JOptionPane.ERROR_MESSAGE);
            return -1;
        }
    }

    @Override public void onUsersChanged(List<String> names) {
        SwingUtilities.invokeLater(() -> showUsers(names));
    }

    @Override public void onLog(String value) {
        SwingUtilities.invokeLater(() -> appendLog(value));
    }

    @Override public void onStatus(String value, boolean running, boolean error) {
        SwingUtilities.invokeLater(() -> {
            portField.setEnabled(!running);
            toggleButton.setText(running ? "Stop server" : "Start server");
            toggleButton.setBackground(running ? RED : GREEN);
            setStatus(value, error);
            if (running) refreshAddresses();
            else showUsers(List.of());
        });
    }

    @Override public void onError(String value) {
        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, value,
                "Study Circle", JOptionPane.ERROR_MESSAGE));
    }

    private void showUsers(List<String> names) {
        usersModel.clear();
        for (String name : names) usersModel.addElement(name);
        usersTitle.setText("Online (" + names.size() + ")");
    }

    private void setStatus(String value, boolean error) {
        statusLabel.setForeground(error ? new Color(255, 130, 130) : new Color(80, 220, 155));
        statusLabel.setText(" " + value);
    }

    private void appendLog(String value) {
        logArea.append(value + "\\n");
        int excess = logArea.getDocument().getLength() - MAX_LOG_CHARS;
        if (excess > 0) logArea.replaceRange("", 0, excess);
    }
}
