package studycircle.server.model;

/** Minimal client-session contract used by the server model without depending on socket handlers. */
public interface ClientSession {
    int getId();
    void setNickname(String nickname);
    void send(String type, String... fields);
    void close();
}
