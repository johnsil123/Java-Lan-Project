package studycircle.server.model;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** A live group poll (server-side state). One vote per connected client. */
final class Poll {
    final int id;
    final String question;
    final String creatorName;
    final ClientSession creator;
    final List<String> options;
    final int[] counts;
    final Map<Integer, Integer> votesByClient = new HashMap<>(); // handlerId -> option index
    boolean open = true;

    Poll(int id, String question, List<String> options, ClientSession creator, String creatorName) {
        this.id = id;
        this.question = question;
        this.options = List.copyOf(options);
        this.counts = new int[options.size()];
        this.creator = creator;
        this.creatorName = creatorName;
    }
}
