package studycircle.server.model;

import java.util.HashSet;
import java.util.Set;

/** One entry in the shared question queue (server-side state). */
final class Question {
    final int id;
    final String asker;
    final String text;
    final Set<Integer> upvoters = new HashSet<>();
    boolean answered;

    Question(int id, String asker, String text, int askerHandlerId) {
        this.id = id;
        this.asker = asker;
        this.text = text;
        this.upvoters.add(askerHandlerId); // asking counts as the first vote
    }

    int votes() {
        return upvoters.size();
    }
}
