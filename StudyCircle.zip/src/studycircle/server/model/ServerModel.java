package studycircle.server.model;

import studycircle.server.ServerLog;

import studycircle.common.Protocol;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Consumer;

/**
 * MODEL (server side): all shared state (users, question queue, polls).
 * Every operation is synchronized, so concurrent client threads can never
 * corrupt the shared data or interleave broadcasts. Methods return an error
 * message (String) when validation fails, or null on success.
 */
public final class ServerModel {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final int MAX_NICK = 20, MAX_TEXT = 500, MAX_QUESTIONS = 200, MAX_POLLS = 50;

    private final Map<ClientSession, String> members = new LinkedHashMap<>();
    private final List<Question> questions = new ArrayList<>();
    private final List<Poll> polls = new ArrayList<>();
    private volatile Consumer<List<String>> usersListener = names -> { };
    private int nextQuestionId = 1;
    private int nextPollId = 1;

    /** Called (on a server thread) whenever the online list changes; used by the server window. */
    public void setUsersListener(Consumer<List<String>> l) { usersListener = l; }

    /** Disconnects every joined client (used when the server is stopped). */
    public synchronized void closeAll() {
        for (ClientSession h : new ArrayList<>(members.keySet())) h.close();
    }

    public static String now() {
        return LocalTime.now().format(TIME);
    }

    // ------------------------------------------------------------ users

    public synchronized String join(ClientSession h, String raw) {
        if (members.containsKey(h)) return "You have already joined.";
        String nick = raw.trim();
        String err = checkNick(h, nick);
        if (err != null) return err;
        members.put(h, nick);
        h.setNickname(nick);
        h.send(Protocol.WELCOME, nick);
        announce(nick + " joined the study circle.");
        broadcastUsers();
        sendQueue(h);
        sendPolls(h);
        return null;
    }

    public synchronized String rename(ClientSession h, String raw) {
        String old = members.get(h);
        if (old == null) return "Join first.";
        String nick = raw.trim();
        if (nick.equals(old)) return "That is already your nickname.";
        String err = checkNick(h, nick);
        if (err != null) return err;
        members.put(h, nick);
        h.setNickname(nick);
        h.send(Protocol.WELCOME, nick);
        announce(old + " is now known as " + nick + ".");
        broadcastUsers();
        return null;
    }

    public synchronized void leave(ClientSession h) {
        String nick = members.remove(h);
        if (nick != null) {
            announce(nick + " left the study circle.");
            broadcastUsers();
            broadcastPolls(); // "canClose" may change if a creator left
        }
    }

    private String checkNick(ClientSession h, String nick) {
        if (nick.isEmpty()) return "Nickname cannot be blank.";
        if (nick.length() > MAX_NICK) return "Nickname must be at most " + MAX_NICK + " characters.";
        if (!nick.matches("[A-Za-z0-9_.-]+"))
            return "Nicknames may only contain letters, numbers, '_', '-' and '.' (no spaces).";
        for (Map.Entry<ClientSession, String> e : members.entrySet()) {
            if (e.getKey() != h && e.getValue().equalsIgnoreCase(nick))
                return "The nickname \"" + nick + "\" is already in use.";
        }
        return null;
    }

    // ------------------------------------------------------------ chat

    public synchronized String chat(ClientSession h, String raw) {
        String nick = members.get(h);
        if (nick == null) return "Join first.";
        String text = raw.trim();
        if (text.isEmpty()) return "Cannot send a blank message.";
        if (text.length() > MAX_TEXT) return "Message too long (max " + MAX_TEXT + " characters).";
        broadcast(Protocol.CHAT, now(), nick, text);
        return null;
    }

    // ------------------------------------------------------------ feature 1: question queue

    public synchronized String ask(ClientSession h, String raw) {
        String nick = members.get(h);
        if (nick == null) return "Join first.";
        String text = raw.trim();
        if (text.isEmpty()) return "A question cannot be blank.";
        if (text.length() > MAX_TEXT) return "Question too long (max " + MAX_TEXT + " characters).";
        if (questions.size() >= MAX_QUESTIONS) return "The question queue is full.";
        Question q = new Question(nextQuestionId++, nick, text, h.getId());
        questions.add(q);
        announce(nick + " added question #" + q.id + " to the queue.");
        broadcastQueue();
        return null;
    }

    public synchronized String upvote(ClientSession h, String idText) {
        if (!members.containsKey(h)) return "Join first.";
        Question q = findQuestion(idText);
        if (q == null) return "That question no longer exists.";
        if (q.answered) return "That question is already answered.";
        if (!q.upvoters.add(h.getId())) return "You already upvoted that question.";
        broadcastQueue();
        return null;
    }

    public synchronized String answer(ClientSession h, String idText) {
        String nick = members.get(h);
        if (nick == null) return "Join first.";
        Question q = findQuestion(idText);
        if (q == null) return "That question no longer exists.";
        if (q.answered) return "That question is already answered.";
        q.answered = true;
        announce(nick + " marked question #" + q.id + " as answered.");
        broadcastQueue();
        return null;
    }

    private Question findQuestion(String idText) {
        int id = Integer.parseInt(idText.trim());
        for (Question q : questions) if (q.id == id) return q;
        return null;
    }

    // ------------------------------------------------------------ feature 2: group poll

    public synchronized String newPoll(ClientSession h, String rawQuestion, List<String> rawOptions) {
        String nick = members.get(h);
        if (nick == null) return "Join first.";
        String question = rawQuestion.trim();
        if (question.isEmpty()) return "A poll needs a question.";
        if (question.length() > 200) return "Poll question too long (max 200 characters).";
        List<String> options = new ArrayList<>();
        for (String o : rawOptions) {
            String t = o.trim();
            if (t.isEmpty()) continue;
            if (t.length() > 60) return "Poll options must be at most 60 characters.";
            for (String existing : options)
                if (existing.equalsIgnoreCase(t)) return "Poll options must be different from each other.";
            options.add(t);
        }
        if (options.size() < 2 || options.size() > 6) return "A poll needs between 2 and 6 options.";
        if (polls.size() >= MAX_POLLS) return "Too many polls in this session.";
        Poll p = new Poll(nextPollId++, question, options, h, nick);
        polls.add(p);
        announce(nick + " started poll #" + p.id + ": " + question);
        broadcastPolls();
        return null;
    }

    public synchronized String vote(ClientSession h, String pollIdText, String optionText) {
        if (!members.containsKey(h)) return "Join first.";
        Poll p = findPoll(pollIdText);
        if (p == null) return "That poll no longer exists.";
        if (!p.open) return "That poll is closed.";
        int idx = Integer.parseInt(optionText.trim());
        if (idx < 0 || idx >= p.options.size()) return "Invalid poll option.";
        if (p.votesByClient.containsKey(h.getId())) return "You already voted in this poll.";
        p.votesByClient.put(h.getId(), idx);
        p.counts[idx]++;
        broadcastPolls();
        return null;
    }

    public synchronized String closePoll(ClientSession h, String pollIdText) {
        String nick = members.get(h);
        if (nick == null) return "Join first.";
        Poll p = findPoll(pollIdText);
        if (p == null) return "That poll no longer exists.";
        if (!p.open) return "That poll is already closed.";
        if (!canClose(h, p)) return "Only the poll creator can close this poll.";
        p.open = false;
        announce(nick + " closed poll #" + p.id + ".");
        broadcastPolls();
        return null;
    }

    private Poll findPoll(String idText) {
        int id = Integer.parseInt(idText.trim());
        for (Poll p : polls) if (p.id == id) return p;
        return null;
    }

    /** Creator can close; if the creator already left, any member can. */
    private boolean canClose(ClientSession h, Poll p) {
        return p.open && (p.creator == h || !members.containsKey(p.creator));
    }

    // ------------------------------------------------------------ broadcasting

    private void announce(String text) {
        ServerLog.log("[" + now() + "] " + text);
        broadcast(Protocol.SYS, now(), text);
    }

    private void broadcast(String type, String... fields) {
        for (ClientSession h : members.keySet()) h.send(type, fields);
    }

    private void broadcastUsers() {
        broadcast(Protocol.USERS, members.values().toArray(new String[0]));
        usersListener.accept(new ArrayList<>(members.values()));
    }

    private void broadcastQueue() {
        for (ClientSession h : members.keySet()) sendQueue(h);
    }

    private void broadcastPolls() {
        for (ClientSession h : members.keySet()) sendPolls(h);
    }

    /** Sends the whole queue (open questions by votes first, answered last). Per-client: includes "you upvoted". */
    private void sendQueue(ClientSession h) {
        List<Question> sorted = new ArrayList<>(questions);
        sorted.sort(Comparator.comparing((Question q) -> q.answered)
                .thenComparingInt(q -> -q.votes())
                .thenComparingInt(q -> q.id));
        String[] items = new String[sorted.size()];
        for (int i = 0; i < items.length; i++) {
            Question q = sorted.get(i);
            items[i] = Protocol.join(String.valueOf(q.id), q.asker, q.text, String.valueOf(q.votes()),
                    String.valueOf(q.answered), String.valueOf(q.upvoters.contains(h.getId())));
        }
        h.send(Protocol.QUEUE, items);
    }

    /** Sends every poll. Per-client: includes "your vote" and whether you may close it. */
    private void sendPolls(ClientSession h) {
        String[] items = new String[polls.size()];
        for (int i = 0; i < items.length; i++) {
            Poll p = polls.get(i);
            List<String> parts = new ArrayList<>();
            parts.add(String.valueOf(p.id));
            parts.add(p.question);
            parts.add(String.valueOf(p.open));
            parts.add(members.getOrDefault(p.creator, p.creatorName));
            parts.add(String.valueOf(p.votesByClient.getOrDefault(h.getId(), -1)));
            parts.add(String.valueOf(canClose(h, p)));
            for (int o = 0; o < p.options.size(); o++) {
                parts.add(p.options.get(o));
                parts.add(String.valueOf(p.counts[o]));
            }
            items[i] = Protocol.join(parts.toArray(new String[0]));
        }
        h.send(Protocol.POLLS, items);
    }
}
