package studycircle.server;

import java.util.function.Consumer;

/** Tiny logging hub: always prints to the console, and also forwards to the server window if one is attached. */
public final class ServerLog {
    private static volatile Consumer<String> sink;

    private ServerLog() {}

    public static void setSink(Consumer<String> s) { sink = s; }

    public static void log(String text) {
        System.out.println(text);
        Consumer<String> s = sink;
        if (s != null) s.accept(text);
    }
}
