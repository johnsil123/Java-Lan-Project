package studycircle.server;

import studycircle.server.controller.ServerController;
import studycircle.server.controller.ClientHandler;
import studycircle.server.model.ServerModel;
import studycircle.server.view.ServerWindow;

import studycircle.common.Protocol;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.awt.GraphicsEnvironment;
import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Server core + entry point.
 *   java studycircle.server.ChatServer [port]             -> opens the server window (JFrame)
 *   java studycircle.server.ChatServer --console [port]   -> console only (also used automatically when headless)
 */
public final class ChatServer {
    private final ServerModel model = new ServerModel();
    private final ExecutorService pool = Executors.newCachedThreadPool(); // one thread per client
    private final Set<ClientHandler> handlers = ConcurrentHashMap.newKeySet();
    private volatile ServerSocket serverSocket;
    private volatile boolean stopped;

    public void setUsersListener(Consumer<List<String>> l) { model.setUsersListener(l); }

    /** Opens the port and starts accepting clients on a background thread. */
    public void start(int port) throws IOException {
        serverSocket = new ServerSocket(port);
        Thread acceptor = new Thread(this::acceptLoop, "accept");
        acceptor.start();
    }

    private void acceptLoop() {
        ServerSocket server = serverSocket;
        while (!stopped) {
            try {
                Socket socket = server.accept();
                try {
                    ClientHandler h = new ClientHandler(socket, model);
                    handlers.add(h);
                    pool.execute(() -> {
                        try { h.run(); } finally { handlers.remove(h); }
                    });
                } catch (IOException e) {
                    ServerLog.log("Could not start handler: " + e.getMessage());
                    try { socket.close(); } catch (IOException ignored) { }
                }
            } catch (IOException e) {
                if (!stopped) ServerLog.log("Server error: " + e.getMessage());
                return;
            }
        }
    }

    /** Stops accepting, disconnects everyone and releases the port. */
    public void stop() {
        stopped = true;
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) { }
        for (ClientHandler h : new ArrayList<>(handlers)) h.close();
        pool.shutdown();
    }

    public static List<String> lanAddresses() {
        List<String> result = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address) {
                        String ip = a.getHostAddress();
                        String adapter = ni.getDisplayName();
                        // Hide the unwanted Qualcomm Atheros adapter/address from the server list.
                        if ("192.168.31.248".equals(ip)
                                || adapter.toLowerCase().contains("qualcomm atheros ar5bwb222")) {
                            continue;
                        }
                        result.add(ip + "  (" + adapter + ")");
                    }
                }
            }
        } catch (SocketException ignored) { }
        return result;
    }

    public static String friendly(IOException e, int port) {
        if (e instanceof BindException)
            return "Port " + port + " is already in use. Close the other server or choose a different port.";
        return "Server error: " + e.getMessage();
    }

    public static void main(String[] args) {
        boolean console = GraphicsEnvironment.isHeadless();
        Integer port = null;
        for (String a : args) {
            if (a.equals("--console") || a.equals("--nogui")) { console = true; continue; }
            try {
                int p = Integer.parseInt(a);
                if (p < 1 || p > 65535) throw new NumberFormatException();
                port = p;
            } catch (NumberFormatException e) {
                System.err.println("Invalid port. Use a number from 1 to 65535.");
                return;
            }
        }
        final int startPort = port == null ? Protocol.DEFAULT_PORT : port;

        if (!console) {
            SwingUtilities.invokeLater(() -> {
                try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) { }
                ServerController controller = new ServerController();
                new ServerWindow(controller, startPort).setVisible(true);
            });
            return;
        }

        ChatServer server = new ChatServer();
        try {
            server.start(startPort);
        } catch (IOException e) {
            System.err.println(friendly(e, startPort));
            return;
        }
        System.out.println("Study Circle server running on port " + startPort);
        for (String a : lanAddresses()) System.out.println("  Clients on the LAN connect to: " + a);
        System.out.println("Press Ctrl+C to stop.");
    }
}
