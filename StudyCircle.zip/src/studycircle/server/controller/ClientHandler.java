package studycircle.server.controller;

import studycircle.server.model.ServerModel;
import studycircle.server.model.ClientSession;
import studycircle.common.Protocol;
import studycircle.server.ServerLog;

import studycircle.common.Protocol;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * CONTROLLER (server side): one instance (and one thread) per connected client.
 * Reads protocol lines, validates them, and delegates to the ServerModel.
 * send() is synchronized so two threads can never mix their output on one socket.
 */
public final class ClientHandler implements Runnable, ClientSession {
    private static final AtomicInteger IDS = new AtomicInteger();
    private static final String[] HELP = {
        "Commands: /name <newname> (change nickname), /exit (leave), /help (this list).",
        "Question Queue tab: ask a question, upvote others, mark answered.",
        "Polls tab: start a poll (2-6 options), vote once, creator closes it."
    };

    private final int id = IDS.incrementAndGet();
    private final Socket socket;
    private final ServerModel model;
    private final BufferedReader in;
    private final PrintWriter out;
    private volatile boolean closed;
    private volatile String nickname = "?";
    private boolean joined;

    public ClientHandler(Socket socket, ServerModel model) throws IOException {
        this.socket = socket;
        this.model = model;
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        this.out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
    }

    public int getId() { return id; }

    public void setNickname(String nickname) { this.nickname = nickname; }

    @Override
    public void run() {
        String who = String.valueOf(socket.getRemoteSocketAddress());
        ServerLog.log("[" + ServerModel.now() + "] Connection opened: " + who);
        try {
            String line;
            while (!closed && (line = in.readLine()) != null) {
                if (!handle(line)) break;
            }
        } catch (IOException e) {
            ServerLog.log("[" + ServerModel.now() + "] Connection lost: " + who + " (" + e.getMessage() + ")");
        } finally {
            model.leave(this);   // frees the nickname and tells everyone else
            close();
            ServerLog.log("[" + ServerModel.now() + "] Connection closed: " + who);
        }
    }

    /** @return false when this client should be disconnected. */
    private boolean handle(String line) {
        if (line.isBlank()) return true;
        if (line.length() > 4000) { send(Protocol.ERR, "Message too long."); return true; }
        String[] f;
        try {
            f = Protocol.parse(line);
        } catch (IllegalArgumentException e) {
            send(Protocol.ERR, "Malformed message.");
            return true;
        }
        String type = f[0];
        if (!joined && !type.equals(Protocol.JOIN) && !type.equals(Protocol.EXIT)) {
            send(Protocol.ERR, "Please join with a nickname first.");
            return true;
        }
        String err = null;
        try {
            switch (type) {
                case Protocol.JOIN -> {
                    err = model.join(this, arg(f, 1));
                    if (err == null) joined = true;
                }
                case Protocol.MSG -> err = model.chat(this, arg(f, 1));
                case Protocol.NAME -> err = model.rename(this, arg(f, 1));
                case Protocol.HELP -> { for (String h : HELP) send(Protocol.SYS, ServerModel.now(), h); }
                case Protocol.ASK -> err = model.ask(this, arg(f, 1));
                case Protocol.UPVOTE -> err = model.upvote(this, arg(f, 1));
                case Protocol.ANSWER -> err = model.answer(this, arg(f, 1));
                case Protocol.POLL_NEW -> {
                    List<String> opts = f.length > 2 ? Arrays.asList(f).subList(2, f.length) : Collections.emptyList();
                    err = model.newPoll(this, arg(f, 1), opts);
                }
                case Protocol.VOTE -> err = model.vote(this, arg(f, 1), arg(f, 2));
                case Protocol.POLL_CLOSE -> err = model.closePoll(this, arg(f, 1));
                case Protocol.EXIT -> { send(Protocol.BYE); return false; }
                default -> err = "Unknown command: " + type;
            }
        } catch (NumberFormatException e) {
            err = "Invalid number in request.";
        }
        if (err != null) send(Protocol.ERR, err);
        return true;
    }

    private static String arg(String[] f, int i) {
        return i < f.length ? f[i] : "";
    }

    public synchronized void send(String type, String... fields) {
        if (closed) return;
        out.println(Protocol.build(type, fields));
        out.flush();
        if (out.checkError()) close();
    }

    public void close() {
        closed = true;
        try { socket.close(); } catch (IOException ignored) { }
    }
}
