package studycircle.server.controller;

import studycircle.server.ChatServer;
import studycircle.server.ServerLog;

import java.io.IOException;
import java.util.List;

/**
 * SERVER CONTROLLER: receives UI actions, controls the server service,
 * and sends server-state updates back to the Swing view.
 */
public final class ServerController {
    public interface Listener {
        void onUsersChanged(List<String> names);
        void onLog(String message);
        void onStatus(String message, boolean running, boolean error);
        void onError(String message);
    }

    private ChatServer server;
    private Listener listener;

    public void setListener(Listener listener) {
        this.listener = listener;
        ServerLog.setSink(this::log);
    }

    public List<String> getLanAddresses() {
        return ChatServer.lanAddresses();
    }

    public synchronized boolean isRunning() {
        return server != null;
    }

    public synchronized void startServer(int port) {
        if (server != null) return;
        if (port < 1 || port > 65535) {
            error("The port must be a number from 1 to 65535.");
            return;
        }
        ChatServer candidate = new ChatServer();
        candidate.setUsersListener(names -> {
            Listener current = listener;
            if (current != null) current.onUsersChanged(names);
        });
        try {
            candidate.start(port);
            server = candidate;
            status("Server is running on port " + port + ".", true, false);
            log("Study Circle server running on port " + port);
            for (String address : ChatServer.lanAddresses()) log("LAN address: " + address);
        } catch (IOException ex) {
            String message = ChatServer.friendly(ex, port);
            status(message, false, true);
            error(message);
        }
    }

    public synchronized void stopServer() {
        if (server == null) return;
        server.stop();
        server = null;
        status("Server is stopped.", false, false);
        log("Server stopped.");
    }

    public synchronized void shutdown() {
        stopServer();
        ServerLog.setSink(null);
    }

    private void status(String message, boolean running, boolean error) {
        Listener current = listener;
        if (current != null) current.onStatus(message, running, error);
    }

    private void error(String message) {
        Listener current = listener;
        if (current != null) current.onError(message);
    }

    private void log(String message) {
        Listener current = listener;
        if (current != null) current.onLog(message);
    }
}
