package studycircle.client;

import studycircle.client.controller.ChatController;
import studycircle.client.model.ChatModel;
import studycircle.client.view.ChatView;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** Client entry point:  java studycircle.client.ClientApp  (wires Model, View and Controller together). */
public final class ClientApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) { }
            ChatModel model = new ChatModel();
            ChatController controller = new ChatController(model);
            ChatView view = new ChatView(model, controller);
            controller.setView(view);
            view.setVisible(true);
        });
    }
}
