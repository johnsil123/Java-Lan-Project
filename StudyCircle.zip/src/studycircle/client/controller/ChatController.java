package studycircle.client.controller;

import studycircle.client.model.ChatModel;
import studycircle.client.model.PollItem;
import studycircle.client.model.QuestionItem;
import studycircle.client.net.ServerConnection;
import studycircle.client.view.ChatView;
import studycircle.common.Protocol;

import javax.swing.SwingUtilities;
import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * CONTROLLER (client side): turns user actions from the view into protocol messages,
 * and turns server messages into model updates. All model/view updates happen on the
 * Swing Event Dispatch Thread; connecting happens on a background thread.
 */
public final class ChatController implements ChatView.Actions {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final ChatModel model;
    private ChatView view;
    private ServerConnection conn;   // current connection (EDT only)
    private boolean connecting;
    private boolean joined;
    private boolean exiting;         // true when the user chose to leave

    public ChatController(ChatModel model) {
        this.model = model;
    }

    public void setView(ChatView view) {
        this.view = view;
    }

    // ---------------------------------------------------------------- user actions

    @Override
    public void onConnect(String hostText, String portText, String nickText) {
        String host = hostText.trim();
        String nick = nickText.trim();
        if (host.isEmpty() || host.contains(" ")) {
            view.showError("Enter a valid server IP address (for example 192.168.1.10) or host name.");
            return;
        }
        int port;
        try {
            port = Integer.parseInt(portText.trim());
            if (port < 1 || port > 65535) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            view.showError("The port must be a number from 1 to 65535.");
            return;
        }
        if (nick.isEmpty()) {
            view.showError("Nickname cannot be blank.");
            return;
        }
        if (connecting) return;
        if (conn != null && conn.isOpen()) {      // socket is open but the nickname was rejected: retry JOIN
            conn.send(Protocol.build(Protocol.JOIN, nick));
            return;
        }

        connecting = true;
        view.showNotice("Connecting to " + host + ":" + port + " ...", false);
        final ServerConnection c = new ServerConnection();
        conn = c;
        new Thread(() -> {
            try {
                c.connect(host, port,
                        line -> SwingUtilities.invokeLater(() -> onLine(c, line)),
                        reason -> SwingUtilities.invokeLater(() -> onClosed(c, reason)));
                c.send(Protocol.build(Protocol.JOIN, nick));
                SwingUtilities.invokeLater(() -> connecting = false);
            } catch (IOException e) {
                SwingUtilities.invokeLater(() -> {
                    connecting = false;
                    if (conn == c) conn = null;
                    c.close();
                    view.showNotice("Could not connect.", true);
                    view.showError("Could not connect to " + host + ":" + port + " - " + friendly(e));
                });
            }
        }, "connect").start();
    }

    @Override
    public void onDisconnect() {
        if (conn == null) return;
        exiting = true;
        conn.send(Protocol.build(Protocol.EXIT));
        conn.close();
    }

    @Override
    public void onSend(String text) {
        String t = text.trim();
        if (t.isEmpty()) {
            view.showNotice("Blank messages are not sent.", true);
            return;
        }
        if (!ensureJoined()) return;
        if (!t.startsWith("/")) {
            conn.send(Protocol.build(Protocol.MSG, t));
            return;
        }
        String[] parts = t.split("\\s+", 2);
        switch (parts[0].toLowerCase()) {
            case "/name" -> {
                if (parts.length < 2 || parts[1].isBlank()) {
                    model.addSystem(now(), "Usage: /name <newname>", true);
                } else {
                    conn.send(Protocol.build(Protocol.NAME, parts[1].trim()));
                }
            }
            case "/exit" -> onDisconnect();
            case "/help" -> conn.send(Protocol.build(Protocol.HELP));
            default -> model.addSystem(now(), "Unknown command \"" + parts[0] + "\". Type /help.", true);
        }
    }

    @Override
    public void onAsk(String text) {
        if (text.isBlank()) {
            view.showNotice("A question cannot be blank.", true);
            return;
        }
        if (ensureJoined()) conn.send(Protocol.build(Protocol.ASK, text.trim()));
    }

    @Override
    public void onUpvote(int questionId) {
        if (ensureJoined()) conn.send(Protocol.build(Protocol.UPVOTE, String.valueOf(questionId)));
    }

    @Override
    public void onAnswer(int questionId) {
        if (ensureJoined()) conn.send(Protocol.build(Protocol.ANSWER, String.valueOf(questionId)));
    }

    @Override
    public void onNewPoll(String question, List<String> options) {
        if (question.isBlank()) {
            view.showNotice("A poll needs a question.", true);
            return;
        }
        if (options.size() < 2) {
            view.showNotice("A poll needs at least 2 options.", true);
            return;
        }
        if (!ensureJoined()) return;
        List<String> fields = new ArrayList<>();
        fields.add(question.trim());
        fields.addAll(options);
        conn.send(Protocol.build(Protocol.POLL_NEW, fields.toArray(new String[0])));
    }

    @Override
    public void onVote(int pollId, int optionIndex) {
        if (ensureJoined()) conn.send(Protocol.build(Protocol.VOTE, String.valueOf(pollId), String.valueOf(optionIndex)));
    }

    @Override
    public void onClosePoll(int pollId) {
        if (ensureJoined()) conn.send(Protocol.build(Protocol.POLL_CLOSE, String.valueOf(pollId)));
    }

    @Override
    public void onWindowClosing() {
        if (conn != null) {
            exiting = true;
            conn.send(Protocol.build(Protocol.EXIT));
            conn.closeAndWait();
        }
        view.dispose();
        System.exit(0);
    }

    // ---------------------------------------------------------------- server messages (EDT)

    private void onLine(ServerConnection c, String line) {
        if (c != conn) return;
        String[] f;
        try {
            f = Protocol.parse(line);
        } catch (IllegalArgumentException e) {
            return; // ignore malformed lines
        }
        try {
            switch (f[0]) {
                case Protocol.WELCOME -> {
                    joined = true;
                    model.setSession(true, f[1]);
                }
                case Protocol.ERR -> {
                    if (joined) {
                        model.addSystem(now(), f[1], true);
                        view.showNotice(f[1], true);
                    } else {
                        view.showError(f[1]);          // e.g. duplicate nickname at join time
                    }
                }
                case Protocol.CHAT -> model.addChat(f[1], f[2], f[3]);
                case Protocol.SYS -> model.addSystem(f[1], f[2], false);
                case Protocol.USERS -> model.setUsers(new ArrayList<>(List.of(f).subList(1, f.length)));
                case Protocol.QUEUE -> model.setQuestions(parseQueue(f));
                case Protocol.POLLS -> model.setPolls(parsePolls(f));
                case Protocol.BYE -> { /* the socket closes next; onClosed handles the cleanup */ }
                default -> { }
            }
        } catch (RuntimeException e) {
            // A malformed server message must never crash the GUI.
            System.err.println("Ignoring bad message: " + line);
        }
    }

    private void onClosed(ServerConnection c, String reason) {
        if (c != conn) return;
        conn = null;
        boolean wasJoined = joined;
        joined = false;
        model.setSession(false, "");
        if (exiting) {
            model.addSystem(now(), "You left the study circle.", false);
        } else if (wasJoined) {
            model.addSystem(now(), "Connection lost: " + reason + ". You can reconnect from the top bar.", true);
            view.showError("Connection to the server was lost (" + reason + ").");
        } else {
            view.showNotice("Disconnected.", true);
        }
        exiting = false;
    }

    private static List<QuestionItem> parseQueue(String[] f) {
        List<QuestionItem> list = new ArrayList<>();
        for (int i = 1; i < f.length; i++) {
            String[] q = Protocol.split(f[i]);
            list.add(new QuestionItem(Integer.parseInt(q[0]), q[1], q[2], Integer.parseInt(q[3]),
                    Boolean.parseBoolean(q[4]), Boolean.parseBoolean(q[5])));
        }
        return list;
    }

    private static List<PollItem> parsePolls(String[] f) {
        List<PollItem> list = new ArrayList<>();
        for (int i = 1; i < f.length; i++) {
            String[] p = Protocol.split(f[i]);
            List<String> options = new ArrayList<>();
            List<Integer> counts = new ArrayList<>();
            for (int k = 6; k + 1 < p.length; k += 2) {
                options.add(p[k]);
                counts.add(Integer.parseInt(p[k + 1]));
            }
            list.add(new PollItem(Integer.parseInt(p[0]), p[1], Boolean.parseBoolean(p[2]), p[3],
                    Integer.parseInt(p[4]), Boolean.parseBoolean(p[5]), options, counts));
        }
        return list;
    }

    // ---------------------------------------------------------------- helpers

    private boolean ensureJoined() {
        if (conn == null || !conn.isOpen() || !joined) {
            view.showNotice("You are not connected. Use the Connect button first.", true);
            return false;
        }
        return true;
    }

    private static String now() {
        return LocalTime.now().format(TIME);
    }

    private static String friendly(IOException e) {
        if (e instanceof ConnectException) return "connection refused. Is the server running, and are the IP and port correct?";
        if (e instanceof SocketTimeoutException) return "the server did not answer in time. Check the IP address and your Wi-Fi.";
        if (e instanceof UnknownHostException) return "unknown host. Check the IP address.";
        return e.getMessage() == null ? "network error." : e.getMessage();
    }
}
