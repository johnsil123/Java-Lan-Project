package studycircle.client.model;

/** One question in the shared queue, as received from the server. */
public record QuestionItem(int id, String asker, String text, int votes, boolean answered, boolean upvotedByMe) { }
