package studycircle.client.model;

import java.util.ArrayList;
import java.util.List;

/**
 * MODEL (client side): everything the GUI displays. It has no Swing code and no sockets.
 * The controller updates it (always on the Swing thread); views subscribe as listeners.
 */
public final class ChatModel {
    public interface Listener {
        default void chatReceived(String time, String sender, String text, boolean mine) { }
        default void systemMessage(String time, String text, boolean error) { }
        default void usersChanged(List<String> users) { }
        default void questionsChanged(List<QuestionItem> questions) { }
        default void pollsChanged(List<PollItem> polls) { }
        default void connectionChanged(boolean connected, String nickname) { }
    }

    private final List<Listener> listeners = new ArrayList<>();
    private String nickname = "";
    private boolean connected;

    public void addListener(Listener l) { listeners.add(l); }

    public String getNickname() { return nickname; }

    public boolean isConnected() { return connected; }

    public void setSession(boolean connected, String nickname) {
        this.connected = connected;
        this.nickname = nickname;
        for (Listener l : listeners) l.connectionChanged(connected, nickname);
    }

    public void addChat(String time, String sender, String text) {
        boolean mine = sender.equals(nickname);
        for (Listener l : listeners) l.chatReceived(time, sender, text, mine);
    }

    public void addSystem(String time, String text, boolean error) {
        for (Listener l : listeners) l.systemMessage(time, text, error);
    }

    public void setUsers(List<String> users) {
        for (Listener l : listeners) l.usersChanged(users);
    }

    public void setQuestions(List<QuestionItem> questions) {
        for (Listener l : listeners) l.questionsChanged(questions);
    }

    public void setPolls(List<PollItem> polls) {
        for (Listener l : listeners) l.pollsChanged(polls);
    }
}
