package studycircle.client.model;

import java.util.List;

/** One poll with live counts, as received from the server. myVote = -1 when you have not voted. */
public record PollItem(int id, String question, boolean open, String creator, int myVote,
                       boolean canClose, List<String> options, List<Integer> counts) {
    public int total() {
        int sum = 0;
        for (int c : counts) sum += c;
        return sum;
    }
}
