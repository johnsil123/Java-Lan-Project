package studycircle.client.net;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.Consumer;

/**
 * Network layer (client side). Owns the Socket.
 *  - a reader thread receives lines and hands them to a callback
 *  - a single-thread executor sends lines, so the GUI thread never blocks on the network
 * Callbacks run on the network threads; the controller moves them onto the Swing thread.
 */
public final class ServerConnection {
    private Socket socket;
    private PrintWriter out;
    private volatile boolean closed;
    private final ExecutorService sender = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "sender");
        t.setDaemon(true);
        return t;
    });

    /** Blocking connect (call from a background thread). Starts the reader thread on success. */
    public void connect(String host, int port, Consumer<String> onLine, Consumer<String> onClosed) throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress(host, port), 4000);
        socket = s;
        out = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8));
        BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
        Thread reader = new Thread(() -> {
            String reason = "the server closed the connection";
            try {
                String line;
                while ((line = in.readLine()) != null) onLine.accept(line);
            } catch (IOException e) {
                reason = closed ? "disconnected" : (e.getMessage() == null ? "network error" : e.getMessage());
            } finally {
                closeSocket();
                onClosed.accept(reason);
            }
        }, "reader");
        reader.setDaemon(true);
        reader.start();
    }

    public boolean isOpen() {
        return socket != null && !closed && !socket.isClosed();
    }

    /** Queues a line for sending (never blocks the caller). */
    public void send(String line) {
        try {
            sender.execute(() -> {
                if (out == null) return;
                out.println(line);
                out.flush();
                if (out.checkError()) closeSocket();
            });
        } catch (RejectedExecutionException ignored) { }
    }

    /** Sends anything already queued, then closes the socket and releases resources. */
    public void close() {
        closed = true;
        try {
            sender.execute(this::closeSocket);
        } catch (RejectedExecutionException ignored) { }
        sender.shutdown();
    }

    /** Like close(), but waits briefly so a queued EXIT is really sent before the JVM exits. */
    public void closeAndWait() {
        close();
        try {
            sender.awaitTermination(500, java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void closeSocket() {
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) { }
    }
}
