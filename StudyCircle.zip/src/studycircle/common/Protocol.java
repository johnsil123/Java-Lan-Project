package studycircle.common;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Shared wire protocol. One message = one line of text:
 *   TYPE|field1|field2|...
 * Every field is URL-encoded so user text can never contain a raw '|' or newline.
 * Composite fields (e.g. one question inside a QUEUE message) are comma-joined,
 * with each part encoded first (see join/split).
 */
public final class Protocol {
    private Protocol() {}

    public static final int DEFAULT_PORT = 5000;

    // ---- Client -> Server ----
    public static final String JOIN = "JOIN";             // JOIN|nick
    public static final String MSG = "MSG";               // MSG|text
    public static final String NAME = "NAME";             // NAME|newNick
    public static final String EXIT = "EXIT";             // EXIT
    public static final String HELP = "HELP";             // HELP
    public static final String ASK = "ASK";               // ASK|questionText
    public static final String UPVOTE = "UPVOTE";         // UPVOTE|questionId
    public static final String ANSWER = "ANSWER";         // ANSWER|questionId
    public static final String POLL_NEW = "POLL_NEW";     // POLL_NEW|question|opt1|opt2|...
    public static final String VOTE = "VOTE";             // VOTE|pollId|optionIndex
    public static final String POLL_CLOSE = "POLL_CLOSE"; // POLL_CLOSE|pollId

    // ---- Server -> Client ----
    public static final String WELCOME = "WELCOME";       // WELCOME|nick   (join OK / rename OK)
    public static final String ERR = "ERR";               // ERR|message
    public static final String CHAT = "CHAT";             // CHAT|time|sender|text
    public static final String SYS = "SYS";               // SYS|time|text
    public static final String USERS = "USERS";           // USERS|nick1|nick2|...
    public static final String QUEUE = "QUEUE";           // QUEUE|item|item|...  (full snapshot)
    public static final String POLLS = "POLLS";           // POLLS|item|item|...  (full snapshot)
    public static final String BYE = "BYE";               // BYE

    public static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    public static String dec(String s) {
        return URLDecoder.decode(s, StandardCharsets.UTF_8);
    }

    /** Builds one protocol line. */
    public static String build(String type, String... fields) {
        StringBuilder sb = new StringBuilder(type);
        for (String f : fields) {
            sb.append('|').append(enc(f));
        }
        return sb.toString();
    }

    /** Parses a line into [type, field1, field2, ...] (fields decoded). */
    public static String[] parse(String line) {
        String[] raw = line.split("\\|", -1);
        String[] out = new String[raw.length];
        out[0] = raw[0];
        for (int i = 1; i < raw.length; i++) {
            out[i] = dec(raw[i]);
        }
        return out;
    }

    /** Joins sub-fields of a composite item with commas (each part encoded). */
    public static String join(String... parts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(enc(parts[i]));
        }
        return sb.toString();
    }

    /** Reverse of join. */
    public static String[] split(String item) {
        String[] raw = item.split(",", -1);
        for (int i = 0; i < raw.length; i++) {
            raw[i] = dec(raw[i]);
        }
        return raw;
    }
}
